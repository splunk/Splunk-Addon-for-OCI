# Binary File Declaration
bin/_cffi_backend.cpython-37m-x86_64-linux-gnu.so: This binary file is provided along with oci module and source code for the same can be found at https://pypi.org/project/oci/
bin/cryptography/hazmat/bindings/_rust.abi3.so: This binary file is provided along with oci module and source code for the same can be found at https://pypi.org/project/oci/
bin/cryptography/hazmat/bindings/_openssl.abi3.so:  This binary file is provided along with oci module and source code for the same can be found at https://pypi.org/project/oci/